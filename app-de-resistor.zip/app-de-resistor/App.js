import { Image, View, Text, SafeAreaView, StyleSheet, TextInput, Button, FlatList, TouchableOpacity, Picker } from 'react-native';
import React, { useState } from 'react';

import Tela1 from './components/Tela1';
import Tela2 from './components/Tela2';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';


const TelaPrincipal = ({navigation}) => {
  return (
    <View style={styles.container}>
    <View style={styles.titulov}>
    <Text style={styles.titulo}>
        Calculadora de Resistores
      </Text></View>
      <View style={styles.buttons}>
    {/* Navegando para a primeira tela */}
      <TouchableOpacity style={styles.touchable} onPress={() => navigation.navigate('Tela1')}>
        <Text>Cor para Valor</Text>
      </TouchableOpacity>
      {/* Navegando para a Segunda tela */}
      <TouchableOpacity style={styles.touchable} onPress={() => navigation.navigate('Tela2')}>
        <Text>Valor para Cor</Text>
      </TouchableOpacity>
      </View>
    </View>
  );
};


const Stack = createNativeStackNavigator();
   function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="TelaPrincipal">
        <Stack.Screen name="TelaPrincipal" component={TelaPrincipal} />
        <Stack.Screen name="Tela1" component={Tela1} />
        <Stack.Screen name="Tela2" component={Tela2} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#13678A',
    flexDirection: 'column',
  },
  buttons: {
    flex: 2,
    justifyContent: 'center',

  },
  touchable: {
    margin: 10,
    padding: 10,
    backgroundColor: '#D9D9D9',
    borderRadius: 5,
    alignSelf: 'center',
    alignContent: 'center',
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: 'black',
  },

  titulo:{
    flex: 1,
    backgroundColor: '',
    borderRadius: 5,
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: 'white',
    textAlign: 'center',
    lineHeight: 60,
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'arial',
    color: 'white',
  },

  titulov:{
  
    backgroundColor: '#0a0908',
    height: 60,
  }
  
});


export default App